import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.PrintStream;

public class TextBrokerUnitTest {
    public static void main(String args[]) throws FileNotFoundException {

        System.out.println(args[0]);
    }
}
