import java.io.*;

public class stub3 {
    //This stub3 is used to see if the other modules can access the string data from other modules.
    public static void main(String[] args) throws IOException, InterruptedException {
        String data = "This is a line of text inside the file coming out of stub3";
        System.out.print(data);
    }
}