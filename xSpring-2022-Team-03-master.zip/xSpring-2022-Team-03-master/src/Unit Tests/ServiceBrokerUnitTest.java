// Dummy Service Broker module used to test whether the Error module can reach the Service Broker.
public class ServiceBrokerUnitTest {
    public static void main(String[] args) {
        System.out.println("Not found");
    }
}
