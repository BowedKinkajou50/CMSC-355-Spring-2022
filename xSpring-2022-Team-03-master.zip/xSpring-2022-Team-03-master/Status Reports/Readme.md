# Status Reports Folder
Weekly/bi-weekly status reports go into this folder

Project Plan Template: https://github.com/VCU-CMSC-355/Template/blob/master/Status%20Reports/Project%20Plan.md

Status Report Template: https://github.com/VCU-CMSC-355/Template/blob/master/Status%20Reports/Status%20Reports.dotx

## 1st Semester

| Document | Tasks | Accomplishments | Issues |
|---|---|---|---|
| Project Plan | Overall week by week plan of milestones | | |
| Week 1 Status Report | | | |
| Week 2 Status Report | | | |
| Week 3 Status Report | | | |
| Week 4 Status Report | | | |
| Week 5 Status Report | | | |
| Week 6 Status Report | | | |
| Week 7 Status Report | | | |
| Week 8 Status Report | | | |
| Week 9 Status Report | | | |
| Week 10 Status Report | | | |
| Week 11 Status Report | | | |
| Week 12 Status Report | | | |
| Week 13 Status Report | | | |
| Week 14 Status Report | | | |
| Week 15 Status Report | | | |
| Week 16 Status Report | | | |

## 2nd Semester

| Document | Tasks | Accomplishments| Issues |
|---|---|---|---|
| Week 1 Status Report | | | |
| Week 2 Status Report | | | |
| Week 3 Status Report | | | |
| Week 4 Status Report | | | |
| Week 5 Status Report | | | |
| Week 6 Status Report | | | |
| Week 7 Status Report | | | |
| Week 8 Status Report | | | |
| Week 9 Status Report | | | |
| Week 10 Status Report | | | |
| Week 11 Status Report | | | |
| Week 12 Status Report | | | |
| Week 13 Status Report | | | |
| Week 14 Status Report | | | |
| Week 15 Status Report | | | |
| Week 16 Status Report | | | |
